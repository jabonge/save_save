package com.example.myapplication.Remote;

public interface APIInterface {
}
